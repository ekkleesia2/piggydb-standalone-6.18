--
-- Fragment Relation
-- 

ALTER TABLE fragment_relation ADD COLUMN priority INT NOT NULL DEFAULT 0;
